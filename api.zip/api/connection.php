<?php
 
 $con = mysqli_connect("localhost","root","","college_voting_app");

?>