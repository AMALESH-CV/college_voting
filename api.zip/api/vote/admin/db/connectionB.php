<?php
//session_start();

//$_SESSION['login_user']="anish";
//echo $_SESSION['login_user'];
//if($_SESSION['login_user']!="")
//echo "no session".$_SESSION['login_user'];



$conn=mysql_connect("localhost","root","");
mysql_select_db("giaan",$conn);
?>