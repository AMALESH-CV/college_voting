<?php
$DB_Server = "localhost";		//your MySQL Server 
$DB_Username = "root";				 //your MySQL User Name 
$DB_Password = "";				//your MySQL Password 
$DB_DBName = "arnatec_inventory";				//your MySQL Database Name
?>