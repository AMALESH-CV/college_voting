<?php
$table="registartion";
$target_path = "uploads/";
$title="registartion";
?>