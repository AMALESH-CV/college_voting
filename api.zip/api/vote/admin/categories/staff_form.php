	<link rel="stylesheet" href="../css/stylee.css">
<form action="staff_insert.php" method="post" id="staff_form" name="staff_form">


<div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Reg No:</label>
                                                <input type="text" name="staff_regno" class="form-control" placeholder="Company">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>First Name:</label>
                                                <input type="text" name="first_name" class="form-control" placeholder="Username" >
                                            </div>
                                        </div>
                                        
                                    </div>

 
    
    
                               <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Last Name</label>
                                                <input type="text" name="last_name" class="form-control" placeholder="Company" >
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                              <label>Gender:</label>
                                                <select name="gender" class="form-control" >
	
    <option>Male</option>
    <option>Female</option>
                </select>                            
                                            
                                               </div>
                                        </div>
                                        
                                    </div>
    
    
   
              <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>DOB</label>
                                                <input type="date" name="dob" class="form-control" placeholder="" >
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Nationality</label>
                                                <input type="text" name="nationality" class="form-control" placeholder="Username" >
                                            </div>
                                        </div>
                                        
                                    </div>

               
               
 
 
              <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>E mail:></label>
                                                <input type="text" name="email_id" class="form-control" placeholder="Company" >
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Land No</label>
                                                <input type="text" name="contact_no" class="form-control" placeholder="Username" >
                                            </div>
                                        </div>
                                        </div>
 
 
                  <div class="row">

 
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Mobile No 2</label>
                                                <input type="text" name="contact_no" class="form-control" placeholder="Company" >
                                            </div>
                                        </div>
                                   

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Mobile 3</label>
                                                <input type="text" name="contact_landno" class="form-control" placeholder="Username">
                                            </div>
                                        </div>
                                        </div>
                                        
                   <div class="row">

    
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Address:</label>
                                                <input type="text" name="address" class="form-control" placeholder="Company" >
                                            </div>
                                        </div>
                                       
                                        
    
    
 
 
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Joining Date:</label>
                                                <input type="text" name="joining_date" class="form-control">
                                            </div>
                                        </div>
                                        </div>
                                                          <div class="row">

                                       
                                        
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Department:</label>
                                                <select name="department" class="form-control" >
	
    <option>BCA</option>
    <option>BSC</option>
    <option>Mtech</option>
    <option>MCA</option>
    <option>MSC</option>
    </select>

                                           
                                            </div>
                                        </div>
                                       
    
 
                                        <div class="col-md-6">
                                        <div class="form-group">
   
   <select name="designation" class="form-control">
    <option value="">Select Designation</option>
    <option value="">HOD</option>
    <option value="">Staff</option>
    </select>
    
    </div>
    </div>
    
    </div>
                      <div class="row">

    
                                        <div class="col-md-6">
                                        <div class="form-group">
	<select name="h_qualification" class="form-control">
    <option>Select Qualification</option>
    <option>Btech</option>
    <option>BCA</option>
    <option>BSC</option>
    <option>Mtech</option>
    <option>MCA</option>
    <option>MSC</option>
    </select>
   
   </div>
   </div>
    
    
                                        <div class="col-md-6">
                                        <div class="form-group">
                                                   <label>Remark:</label>

    <textarea name="remark" class="form-control"></textarea>
    </div>
    </div>
    </div>
    
    
    <align="center" ><input name="reg_no" type="submit" value="Next >>" />&nbsp;&nbsp;
        <input name="submit" type="submit" value="Finish" />

 
 
 

</form>