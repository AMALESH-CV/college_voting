<?php
$table="categories";
$target_path = "uploads/";
$title="categories";
?>