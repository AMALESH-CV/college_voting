<?php
include("../common/menu.php");
//	echo $_SESSION['privelage'];
?>

    <style>
#right
{
	
float:right;	
color:#333;
font-size:12px;
}
</style>

<style>
#right
{
	
float:right;	
color:#333;
font-size:12px;
}
.userd
{
color:#333;	
}
.red
{
background:#FFECF4;
padding:10px;	
}


#right
{
	
float:right;	
color:#333;
font-size:12px;
}
.userd
{
color:#333;	
}
.red
{
background:#FFECF4;
padding:10px;	
}
.table
{
margin-bottom:10px;
background:#E6F4FF;	
}
.sep
{
height:30px;
background:#666;	
}
</style>
       


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                                             
                            </div>
                            <div class="content all-icons">
                                <div class="row">
                                <div class="col-sm-12">
                                
                                <?php
							//	echo "PRIVELAGE :: ".$_SESSION['privelage'];
							include("../connection.php");	
									
								
								
								
								
								
								
								
								?>
                                
                                
                                 
                              
                                
                                <!-- <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                 <a href="../diocese/form.php">    <div class="font-icon-detail"><i class="pe-7s-culture"></i> 
                                      <input type="text" value="Dioceses">
                                    </div>
</a>
                                  </div>
                                
                                -->
                              
                                 <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                <a href="../voters/form.php">    <div class="font-icon-detail"><i class="pe-7s-add-user"></i>
                                      <input type="text" value="Users">
                                    </div></a>
                                  </div>
                              
                                  
                                  
                                   <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                <a href="../dec/simplechain.php">    <div class="font-icon-detail"><i class="pe-7s-add-user"></i>
                                      <input type="text" value="Generat Block">
                                    </div></a>
                                  </div>
                              
                                  
                                  
                                  
                                   <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                <a href="../categories/form.php">    <div class="font-icon-detail"><i class="pe-7s-add-user"></i>
                                      <input type="text" value="Category">
                                    </div></a>
                                  </div>
                              
                                  
                            
                                
                          
                                </div>


                            </div>
                        </div>
                    </div>

                </div>



                
            </div>
        </div>


        

    </div>
    
     
    
    
    
</div>


</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="../assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	

</html>
