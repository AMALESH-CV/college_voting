<?php
include("../common/menu.php");
	error_reporting(0);
?>

    
    <style>
	.zoom {

  transition: transform .2s; /* Animation */
  
 
  margin: 0 auto;
  border-radius:50px;
}

.zoom:hover {
  transform: scale(8.5); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
	
	</style>
       


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            
                             <div class="content">