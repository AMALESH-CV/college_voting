<?php
$table="categories";

$title="categories";
?>