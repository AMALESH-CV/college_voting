<?php
$table="election";
$target_path = "uploads/";
$title="election";
?>