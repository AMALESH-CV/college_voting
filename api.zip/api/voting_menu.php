<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
 
  	<center><h2><b><p style = "background-color:#2F3C7E;color:white">SELECT OPTION</p></b></h2></center>
    


     

	
     
     
    
   <br>
    <center>
      <a href="voting.php">
    <button style="background-color:#2F3C7E;color:white;height:50px;width:200px;border-radius:6px;margin-top:50px;">MALE</button>
  </a>
    <br>
     <button style="background-color:#2F3C7E;color:white;height:50px;width:200px;border-radius:6px;margin-top:30px;">FEMALE</button>
  </center>
  </form>




 </div>
  </body>
  </html>