<?php 

include("connection.php");

$email = $_POST['email'];
$password = $_POST['password'];  

/*$email = "alanbaby@gmail.com";
$password = "12345";*/

$sql = "SELECT * FROM login where user_name = '$email' and password = '$password'";
$result = mysqli_query($con,$sql);

$sql2 = "SELECT * from student where email = '$email' ";

if(mysqli_num_rows($result)>0){
	$res2=mysqli_query($con,$sql2);
	$row = mysqli_fetch_assoc($res2);
	$data[] = array('id'=> $row['id']);
	echo json_encode($data);
}
else{
	echo "failed";
}
?>