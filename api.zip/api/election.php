<?php
include("header.php");
include("connection.php");
error_reporting(0);

?>
 <h4>Elections</h4>
    
	
                              <?php

								$sel="select * from election where status='0'"; 
									
								
								$res=mysqli_query($con,$sel);
								while($row=mysqli_fetch_array($res))
								{

                        
							?>
							<div class="well" style="margin: 20px; margin-bottom: -15px;">

								<label>Election Name: </label><?php echo $row[election_name]; ?><br>
								<label>Nomination LastDate </label><?php echo $row[nomination_lastdate]; ?><br>
								<label>First Publication: </label><?php echo $row[first_publication]; ?><br>
								<label>Second Publication: </label><?php echo $row[second_publication]; ?><br>
								<label>Election Date: </label><?php echo $row[elect_date]; ?><br>
								<label>Result Publication: </label><?php echo $row[result_publication]; ?><br>

								<a href='nomination.php?id=<?php echo $row[id]?>&uid=<?php echo$_REQUEST[uid] ?>' class='btn btn-primary'
									style="margin-left: 55px;margin-top: 10px;">Submit Nomination</a>
                      
                             </div>
                             <br> <br>


							<?php
								}
                            
							?>  
                                
        