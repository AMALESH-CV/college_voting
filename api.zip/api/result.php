<?php

 echo"Result page";
?>