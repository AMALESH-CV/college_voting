<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
  	<center><h2><b><p style = "color:white;background-color:#2F3C7E;">MALE CANDIDATES</p></b></h2></center>
    

   <input type="hidden" name="uid" value='<?php echo $_REQUEST['uid'] ?>'>

     <label style="margin-top:30px;">ENTER TOKEN:</label><input type="text" name="token" class='form-control' required><br>



     

	<?php

       include("connection.php");
       error_reporting(0);
	  
	  
	  $sql2 = "select *  from candidate ";
    $result2 = mysqli_query($con, $sql2) or die("Error in Selecting " . mysqli_error($connection));
    while($row=mysqli_fetch_array($result2))
    {
?>

<center>
  <button style="background-color:#2F3C7E;color:white;height:75px;width:300px;border-radius:6px;margin-top:10px;margin-right:10px;">
<img src="potrait.jpg" height="50px;" width="50px" style="border-radius:20px;margin-right:10px;"> 
    <?php echo $row['candidate_name'] ?>
      
    </button><input type="radio" name="vid" required>
 
  </center>   
<?php
}
?>    
   <br>
     <center>  <input type="submit" value="VOTE" style="width:150px;background:darkgreen;color: white;height:40px;border-radius:6px;font-weight: bold;"><center> 
  </form>

  <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submiit']))
       {

         $token = $_POST['token'];
         $serid = $_POST['sid'];
         $issue = $_POST['issue'];
         $desc = $_POST['desc'];
         $date = $_POST['date'];    
  
        
        $ins="INSERT INTO service_rqst(cust_id,serv_id,issue,description,serv_date,status) VALUES('$userid','$serid','$issue','$desc','$date','REQUEST')";
         $res= mysqli_query($con,$ins);
          if($res)
          {
             echo "<script>
             alert('Booked');

             </script>";

          }

        }
     ?>


 </div>
  </body>
  </html>