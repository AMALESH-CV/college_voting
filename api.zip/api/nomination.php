<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
  	<!--<center><h2><b><p style = "color:green">Nomination</p></b></h2></center> -->
    
    <center> <img src='../nomination/uploads/nominations3.jpg'  width='200px' height='200px' /> </center><br>

   <input type="hidden" name="uid" value='<?php echo $_REQUEST['uid'] ?>'>
   <input type="hidden" name="did" value='<?php echo $_REQUEST['id'] ?>'>
     <label>DESCRIPTION:</label><textarea name="desc" class='form-control' rows="5"></textarea><br>
     <label>IMAGE:</label><input type="file" name="image" class='form-control'><br>
    
   <br>
     <center>  <input type="submit"name="submit" style="width:150px;background:darkgreen;color: white;height:40px;"><center> 
  </form>
     <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submit']))
       {

         $u = $_REQUEST['uid'];
        $desc = $_POST['desc'];
        $image = $_POST['image'];  

        
        $ins="INSERT INTO candidate(desc) VALUES('$desc') WHERE id='$u'";
        //echo $ins;
         $res= mysqli_query($con,$ins);
          if($res)
          {
             $id = mysqli_insert_id($con);
             $fileName = "student".$id.".jpg";
             file_put_contents("../nomination/uploads/".$fileName, base64_decode($imageFile));

            $sql = "UPDATE candidate SET photo ='$fileName' WHERE id ='$id'";
            mysqli_query($con,$sql);
            echo "success";
          }
          else{
            echo "failed";
          }

        }
     ?>


 </div>
  </body>
  </html>