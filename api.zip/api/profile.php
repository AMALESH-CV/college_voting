<?php

include("connection.php");

if($_REQUEST['uid'] != "")
{
    $query = "SELECT * FROM student WHERE id='$_REQUEST[uid]'";
    $result = mysqli_query($con,$query);
    // $arr=mysqli_fetch_array($result);

    // $email=$arr['user_name'];
    // $res=mysqli_query($con,"select * from student where email='$email'");



    $data = array();

    while($row = mysqli_fetch_assoc($result))
    {
        $data['data'][] = $row;
    }

    echo json_encode($data);

}
else
 echo "";

?>